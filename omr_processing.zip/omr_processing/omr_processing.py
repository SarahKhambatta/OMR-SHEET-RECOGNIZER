import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from PIL import Image
import pytesseract
import mysql.connector
import os
import re
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Database configuration
db_config = {
    'user': 'root',
    'password': 'rachita',
    'host': 'localhost',
    'database': 'omr_system'
}

# Global variables
candidates_data = []

def sanitize_filename(filename):
    """Remove invalid characters from a filename and limit its length."""
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
    return sanitized[:50]  # Truncate to 50 characters

def connect_db():
    """Establish a connection to the database."""
    try:
        conn = mysql.connector.connect(**db_config)
        logger.info("Database connection established.")
        return conn
    except mysql.connector.Error as err:
        logger.error("Database connection failed: %s", str(err))
        messagebox.showerror("Database Error", str(err))
        return None

def process_omrs():
    """Process OMR images and insert data into the database."""
    global candidates_data
    directory = filedialog.askdirectory(title="Select OMR Images Directory")
    if not directory:
        return

    # Create a directory to store images
    image_dir = "omr_images"
    os.makedirs(image_dir, exist_ok=True)

    # Read images from the directory
    image_files = [f for f in os.listdir(directory) if f.endswith(('.png', '.jpg', '.jpeg'))]
    if len(image_files) < 1:
        messagebox.showerror("Error", "Please ensure there is at least 1 OMR sheet image in the selected directory.")
        return

    candidates_data = []
    
    for image_file in image_files:
        image_path = os.path.join(directory, image_file)
        image = Image.open(image_path)

        # Convert the image to RGB if it's in RGBA mode
        if image.mode == 'RGBA':
            image = image.convert('RGB')

        # Use pytesseract to extract text from the image
        extracted_text = pytesseract.image_to_string(image)

        # Mock processing of extracted text
        lines = extracted_text.splitlines()
        roll_number = sanitize_filename(lines[0][:100]) if len(lines) > 0 else "Unknown"  # Ensure length fits the database
        booklet = sanitize_filename(lines[1][:100]) if len(lines) > 1 else "Unknown"  # Ensure length fits the database
        test_code = sanitize_filename(lines[2][:100]) if len(lines) > 2 else "Unknown"  # Ensure length fits the database

        # Generate unique filenames for images
        img_filename = f"img_{roll_number}_{booklet}_{test_code}.jpg"
        img_path = os.path.join(image_dir, img_filename)
        image.save(img_path)  # Save the image

        # Mock invigilator signature (for demonstration purposes)
        img_invigilator_filename = f"invigilator_{roll_number}_{booklet}_{test_code}.jpg"
        img_invigilator_path = os.path.join(image_dir, img_invigilator_filename)
        image.save(img_invigilator_path)  # Save the invigilator image

        # Store candidate data
        candidates_data.append((roll_number, booklet, test_code, img_path, img_invigilator_path))

        # Insert into database
        conn = connect_db()
        if conn is None:
            return  # Exit if connection failed
        try:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT IGNORE INTO Candidates (ROLL_NUMBER, BOOKLET, TEST_CODE, IMG_SIGN, IMG_INVIGILATOR_SIGN) 
                VALUES (%s, %s, %s, %s, %s)
            """, (roll_number, booklet, test_code, img_path, img_invigilator_path))
            conn.commit()
            logger.info("Inserted data for Roll Number: %s", roll_number)
        except mysql.connector.Error as err:
            logger.error("Error inserting data: %s", str(err))
            messagebox.showerror("Database Error", str(err))
        finally:
            cursor.close()
            conn.close()

    load_candidates()

def load_candidates():
    """Load candidates from the database and display them in the tree view."""
    global candidates_data
    for i in tree.get_children():
        tree.delete(i)

    conn = connect_db()
    if conn is None:
        return  # Exit if connection failed
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT ROLL_NUMBER, BOOKLET, TEST_CODE FROM Candidates")
        candidates = cursor.fetchall()
        cursor.close()

        for candidate in candidates:
            tree.insert("", "end", values=candidate)
    except mysql.connector.Error as err:
        logger.error("Error loading candidates: %s", str(err))
        messagebox.showerror("Database Error", str(err))
    finally:
        conn.close()

# GUI setup
root = tk.Tk()
root.title("OMR Processing System")

frame = ttk.Frame(root)
frame.pack(padx=10, pady=10)

tree = ttk.Treeview(frame, columns=("Roll Number", "Booklet", "Test Code"), show='headings')
tree.heading("Roll Number", text="Roll Number")
tree.heading("Booklet", text="Booklet")
tree.heading("Test Code", text="Test Code")
tree.pack()

process_button = ttk.Button(root, text="Process OMRs", command=process_omrs)
process_button.pack(pady=10)

load_button = ttk.Button(root, text="Load Candidates", command=load_candidates)
load_button.pack(pady=10)

# Exit button
exit_button = ttk.Button(root, text="Exit", command=root.quit)
exit_button.pack(pady=10)

root.mainloop()
